# Fortran77 Grammar

Olivier Dragon Thu Jun 28, 2007 17:32. A Fortran 77 grammar for ANTLR v2.

Ported to Antlr4 by Tom Everett, 2016.
