#include <iostream.h>

using namespace std;

int main()
{
    if (not false) {
        cout << "Hello World!";
    }
    return 0;
}

