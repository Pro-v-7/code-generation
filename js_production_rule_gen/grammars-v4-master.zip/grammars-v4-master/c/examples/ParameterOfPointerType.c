//parameter contains pointer
int
__cdecl
f1 (
   const MyType        *param1,
   int                  param2
  );


MyType1
__cdecl
f1 (
   MyType        *param1,
   int       *     param2
  );


void
__cdecl
f1 (
   void        *param1
  );