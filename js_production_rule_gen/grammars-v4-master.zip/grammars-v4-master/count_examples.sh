#!/bin/sh

find . * | grep examples/ | wc -l

