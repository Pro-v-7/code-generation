# MASM grammar

MASM forward ported from Antlr3 ASM. The original readme for the Antlr3 ASM grammar was

> This is a very simple grammar of a pentium asm.
You will find the lexical and parser specifications
in the file and obviously it still lacks many rules.
It is intended to be used only for educational purposes.
It was written by my teamwork (Hugo Garza and Joaqu?n Moreno) and me (Miguel Ugalde),
for a computational theory class project.
We all attend Monterrey Tech in Cuernavaca.
We will appreciate so much your feedback at A00378918@itesm.mx