class MyClass {
  final stringWithBackslashes = "Escaping\ spaces\ should work";
}
