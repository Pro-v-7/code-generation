clu grammar

https://en.wikipedia.org/wiki/CLU_(programming_language)
