# Known Validation Issues

## cbc.html

This file contains unescaped entities inside attributes at line 378

## feedly.html

This file contains an illegal `'"'` at line 14

## yahoo.html

This file contains an unescaped single quote at line 471

## slashdot.html

This file contains invalid Javascript at line 3298
