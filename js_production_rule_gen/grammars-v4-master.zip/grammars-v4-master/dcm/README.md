# DCM Grammar

An ANTLR4 grammar for DCM files.

Ported to Antlr4 by Tom Everett from the Antlr3 Grammer by Donn Shull.
